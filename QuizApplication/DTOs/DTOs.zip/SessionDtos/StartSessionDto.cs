﻿namespace QuizApplication.DTOs.SessionDtos
{
    public class StartSessionDto
    {
        public int QuizId { get; set; }
    }
}
